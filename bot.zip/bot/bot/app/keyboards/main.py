# -*- coding: utf-8 -*-

from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup


def main_menu(is_admin: bool, *, has_subscription: bool) -> InlineKeyboardMarkup:
    rows = [
    [InlineKeyboardButton(text='🛒 Купить', callback_data='buy')],
    ]
    if has_subscription:
        rows.append([
            InlineKeyboardButton(text='📱 Устройства', callback_data='devices'),
        ])
        rows.append([
            InlineKeyboardButton(text='🧠 Режимы', callback_data='modes'),
            InlineKeyboardButton(text='📊 Трафик', callback_data='traffic'),
            InlineKeyboardButton(text='🎁 Рефералы', callback_data='ref'),
        ])
    rows.append([
        InlineKeyboardButton(text='🆘 Поддержка', callback_data='support'),
        InlineKeyboardButton(text='❓ FAQ', callback_data='faq'),
    ])
    if is_admin:
        rows.append([InlineKeyboardButton(text='🛠 Admin', callback_data='admin')])
    return InlineKeyboardMarkup(inline_keyboard=rows)
