# -*- coding: utf-8 -*-

from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from ..models import Device
from ..services.devices import DEVICE_TYPES


def _type_title(device_type: str) -> str:
    return DEVICE_TYPES.get(device_type, device_type)

def devices_list_kb(devices: list[Device], *, can_add: bool) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    for d in devices:
        status = '✅' if d.status == 'active' else '⛔️'
        title = f"{status} {_type_title(d.device_type)} {d.label or ''}".strip()
        rows.append([InlineKeyboardButton(text=title, callback_data=f'dev:view:{d.id}')])

    if can_add:
        rows.append([InlineKeyboardButton(text='➕ Добавить устройство', callback_data='dev:add')])

    rows.append([InlineKeyboardButton(text='⬅️ Назад', callback_data='back')])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def device_menu_kb(device_id: int, *, is_active: bool) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = [
        [InlineKeyboardButton(text='🔗 Получить конфиг', callback_data=f'dev:cfg:{device_id}')],
        [InlineKeyboardButton(text='✏️ Переименовать', callback_data=f'dev:rename:{device_id}')],
        [InlineKeyboardButton(text='🧪 Проверить доступ', callback_data=f'dev:check:{device_id}')],
    ]
    if is_active:
        rows.append([InlineKeyboardButton(text='⛔️ Отключить', callback_data=f'dev:toggle:{device_id}')])
    else:
        rows.append([InlineKeyboardButton(text='✅ Включить', callback_data=f'dev:toggle:{device_id}')])
    rows.append([InlineKeyboardButton(text='🗑 Удалить', callback_data=f'dev:del:{device_id}')])
    rows.append([InlineKeyboardButton(text='⬅️ Назад', callback_data='devices')])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def device_type_kb() -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(text='📱 Телефон', callback_data='dev:type:phone'),
            InlineKeyboardButton(text='💻 ПК', callback_data='dev:type:pc'),
        ],
        [
            InlineKeyboardButton(text='📺 ТВ', callback_data='dev:type:tv'),
            InlineKeyboardButton(text='📟 Планшет', callback_data='dev:type:tablet'),
        ],
        [
            InlineKeyboardButton(text='📡 Роутер', callback_data='dev:type:router'),
            InlineKeyboardButton(text='🔧 Другое', callback_data='dev:type:other'),
        ],
        [InlineKeyboardButton(text='⬅️ Назад', callback_data='devices')],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)
