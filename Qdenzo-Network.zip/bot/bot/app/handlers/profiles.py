# -*- coding: utf-8 -*-

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, Message

from ..config import settings
from ..db import session_scope
from ..keyboards.nav import nav_kb
from ..keyboards.profiles import (
    PROFILES,
    modes_root_kb,
    profiles_account_kb,
    profiles_device_list_kb,
    profiles_device_modes_kb,
)
from ..services.devices import get_device, list_devices, set_device_profile, type_title
from ..services.users import get_user_by_tg_id
from ..services.profiles import get_profile_code, set_profile_code
from ..services.subscriptions import get_or_create_subscription, is_active
from ..utils.telegram import edit_message_text, safe_answer_callback, send_html_with_photo
from ..utils.text import h

router = Router()


def _allowed_profiles(plan_code: str) -> set[str]:
    plan = (plan_code or "").lower()
    if plan == "family":
        return {"smart", "stream", "game", "low", "work", "kids"}
    if plan == "pro":
        return {"smart", "stream", "game", "low", "work"}
    # start / trial / unknown
    return {"smart", "low", "work"}


@router.callback_query(F.data.in_({"profiles", "modes"}))
@router.message(Command("profiles"))
async def show_profiles(event) -> None:
    if isinstance(event, Message):
        tg_id = event.from_user.id
        is_cb = False
    else:
        tg_id = event.from_user.id
        is_cb = True

    async with session_scope() as session:
        user = await get_user_by_tg_id(session, tg_id)
        if not user:
            if is_cb:
                await event.answer("Сначала нажмите /start", show_alert=True)
            else:
                await event.answer("Сначала нажмите /start")
            return

        sub = await get_or_create_subscription(session, user.id)

    if not is_active(sub):
        text = (
            "⛔️ <b>Режимы доступны только при активной подписке.</b>\n\n"
            "Оформите тариф в разделе <b>Купить</b> / <b>Управление</b>."
        )
        if is_cb:
            await edit_message_text(event, text, reply_markup=nav_kb(back_cb="buy", home_cb="back"))
        else:
            await send_html_with_photo(
                event,
                text,
                reply_markup=nav_kb(back_cb="buy", home_cb="back"),
                photo_path=settings.start_photo_path,
            )
        if is_cb:
            await event.answer()
        return


    text = (
        "🧠 <b>Режимы — профили использования</b>\n\n"
        "Настройте приоритеты скорости и стабильности.\n"
        "Выберите, куда применить режим:"
    )
    if is_cb:
        await edit_message_text(event, text, reply_markup=modes_root_kb())
    else:
        await send_html_with_photo(
            event,
            text,
            reply_markup=modes_root_kb(),
            photo_path=settings.start_photo_path,
        )
    if is_cb:
        await event.answer()



@router.callback_query(F.data == "profiles:account")
async def cb_profiles_account(call: CallbackQuery) -> None:
    await safe_answer_callback(call)

    async with session_scope() as session:
        user = await get_user_by_tg_id(session, call.from_user.id)
        if not user:
            await  safe_answer_callback(call, "Сначала /start", show_alert=True)
            return

        sub = await get_or_create_subscription(session, user.id)
        current = await get_profile_code(session, user.id)

    if not is_active(sub):
        await edit_message_text(
            call,
            "⛔️ Режимы доступны только при активной подписке.",
            reply_markup=nav_kb(back_cb="buy", home_cb="back"),
        )
        await  safe_answer_callback(call, )
        return

    allowed = _allowed_profiles(sub.plan_code)
    await _render_account_modes(call, current=current, allowed=allowed)
    await  safe_answer_callback(call, )


@router.callback_query(F.data == "profiles:device")
async def cb_profiles_device(call: CallbackQuery) -> None:
    await safe_answer_callback(call)
    async with session_scope() as session:
        user = await get_user_by_tg_id(session, call.from_user.id)
        if not user:
            await  safe_answer_callback(call, "Сначала /start", show_alert=True)
            return

        sub = await get_or_create_subscription(session, user.id)
        devices = await list_devices(session, user.id)

    if not is_active(sub):
        await edit_message_text(
            call,
            "⛔️ Режимы доступны только при активной подписке.",
            reply_markup=nav_kb(back_cb="buy", home_cb="back"),
        )
        await  safe_answer_callback(call, )
        return

    items = [
        (d.id, f"{type_title(d.device_type)} {h(d.label or '')}".strip())
        for d in devices
        if d.status != "deleted"
    ]
    if not items:
        await edit_message_text(
            call,
            "У вас пока нет устройств. Сначала добавьте устройство.",
            reply_markup=nav_kb(back_cb="profiles", home_cb="back"),
        )
        await  safe_answer_callback(call, )
        return

    await edit_message_text(
        call,
        "📱 <b>Выберите устройство</b>, чтобы применить режим:",
        reply_markup=profiles_device_list_kb(items),
    )
    await  safe_answer_callback(call, )


@router.callback_query(F.data.startswith("profiles:device:"))
async def cb_profiles_device_modes(call: CallbackQuery) -> None:
    await safe_answer_callback(call)
    device_id = int(call.data.split(":")[-1])

    async with session_scope() as session:
        user = await get_user_by_tg_id(session, call.from_user.id)
        if not user:
            await  safe_answer_callback(call, "Сначала /start", show_alert=True)
            return

        sub = await get_or_create_subscription(session, user.id)
        device = await get_device(session, device_id, user_id=user.id)

    if not is_active(sub):
        await edit_message_text(
            call,
            "⛔️ Режимы доступны только при активной подписке.",
            reply_markup=nav_kb(back_cb="buy", home_cb="back"),
        )
        await  safe_answer_callback(call, )
        return

    if not device or device.status == "deleted":
        await  safe_answer_callback(call, "Устройство не найдено", show_alert=True)
        return

    await _render_device_modes(call, device=device, sub=sub)
    await  safe_answer_callback(call, )


@router.callback_query(F.data.startswith("profile_apply:account:"))
async def cb_apply_to_account(call: CallbackQuery) -> None:
    await safe_answer_callback(call)
    code = call.data.split(":")[-1]

    async with session_scope() as session:
        user = await get_user_by_tg_id(session, call.from_user.id)
        if not user:
            await  safe_answer_callback(call, "Сначала /start", show_alert=True)
            return
        sub = await get_or_create_subscription(session, user.id)
        if not is_active(sub):
            await  safe_answer_callback(call, "Подписка не активна", show_alert=True)
            return

        allowed = _allowed_profiles(sub.plan_code)
        if code not in allowed:
            await  safe_answer_callback(call, "Недоступно на вашем тарифе", show_alert=True)
            return

        await set_profile_code(session, user.id, code)

    await _render_account_modes(call, current=code, allowed=allowed)
    await  safe_answer_callback(call, "✅ Применено")


@router.callback_query(F.data.startswith("profile_apply:device:"))
async def cb_apply_to_device(call: CallbackQuery) -> None:
    await safe_answer_callback(call)
    _, _, device_id_s, code = call.data.split(":", 3)
    device_id = int(device_id_s)

    async with session_scope() as session:
        user = await get_user_by_tg_id(session, call.from_user.id)
        if not user:
            await  safe_answer_callback(call, "Сначала /start", show_alert=True)
            return

        sub = await get_or_create_subscription(session, user.id)
        if not is_active(sub):
            await  safe_answer_callback(call, "Подписка не активна", show_alert=True)
            return

        allowed = _allowed_profiles(sub.plan_code)
        if code not in allowed:
            await  safe_answer_callback(call, "Недоступно на вашем тарифе", show_alert=True)
            return

        device = await get_device(session, device_id, user_id=user.id)
        if not device or device.status == "deleted":
            await  safe_answer_callback(call, "Устройство не найдено", show_alert=True)
            return

        if code not in {p[0] for p in PROFILES}:
            await  safe_answer_callback(call, "Неизвестный режим", show_alert=True)
            return


        device = await set_device_profile(session, device, code)

    await _render_device_modes(call, device=device, sub=sub)
    await  safe_answer_callback(call, "✅ Применено")


async def _render_device_modes(call: CallbackQuery, *, device, sub) -> None:
    await safe_answer_callback(call)
    allowed = _allowed_profiles(sub.plan_code)
    current = device.profile_code

    text = (
        f"📱 <b>{h(type_title(device.device_type))} {h(device.label or '')}</b>\n\n"
        f"Текущий режим: <b>{h(current or '—')}</b>\n\n"
        "Выберите режим ниже:"
    )
    await edit_message_text(call, text, reply_markup=profiles_device_modes_kb(device.id, current, allowed=allowed))


async def _render_account_modes(call: CallbackQuery, *, current: str | None, allowed: set[str]) -> None:
    await safe_answer_callback(call)
    text = (
        "👤 <b>Режимы для аккаунта</b>\n\n"
        f"Текущий режим: <b>{h(current or '—')}</b>\n\n"
        "Выберите режим ниже:"
    )
    await edit_message_text(call, text, reply_markup=profiles_account_kb(current, allowed=allowed))
